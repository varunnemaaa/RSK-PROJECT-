"""
QriusAI — RSK Statewide Safety, Protection & Wellbeing Programme
Synthetic sample dataset generator for Deepti Nema's "Final Data Model (Star Schema)".

Produces an Excel workbook with one sheet per table, matching the attached data model
exactly (Dim_Date, Dim_District, Dim_Institute, Dim_Student, Dim_Employee, Dim_Module,
Dim_Question, Fact_Response_Student, Fact_Response_Employee), plus two bonus reference
tables needed to power the KPI tiles already shown in the Main/District/State dashboard
wireframes (Ref_Coverage_Targets, Fact_Action_Points) — flagged clearly as additions
beyond the original diagram, in the same spirit as its own "Optional Additions" box.

Everything here is FAKE DATA for prototyping the Power BI model, DAX and dashboard pages.
Rerun with SCALE="full" to generate at the real programme's scale (798 institutions,
55 districts) once you're ready to move past prototyping.

Usage:
    python3 generate_rsk_sample_data.py
"""

import numpy as np
import pandas as pd
from datetime import date, timedelta

RNG = np.random.default_rng(42)

# --------------------------------------------------------------------------------------
# SCALE — flip to "full" and adjust INSTITUTES_PER_DISTRICT / district list to go statewide
# --------------------------------------------------------------------------------------
SCALE = "sample"   # "sample" (prototyping, ~50 institutes) | "full" (798 institutions, needs full 55-district list)

# --------------------------------------------------------------------------------------
# 1. DISTRICTS — same 5 already used in the Main/District/State wireframes, plus 3 more
#    spread across MP's other regions, for a realistic statewide spread in the sample.
# --------------------------------------------------------------------------------------
DISTRICTS = [
    ("BPL", "Bhopal"),
    ("IND", "Indore"),
    ("DEW", "Dewas"),
    ("DHR", "Dhar"),
    ("UJN", "Ujjain"),
    ("JBP", "Jabalpur"),
    ("SGR", "Sagar"),
    ("REW", "Rewa"),
]

# --------------------------------------------------------------------------------------
# 2. MODULES — exact names + order from the WS1 Detailed Outline table (Phase I / Phase II)
#    Pillar mapping follows the WS2 outline's own "M&E Indicators -> Instrument Mapping"
#    (Modules 1-2 = POCSO, Module 4 = POSH, Modules 5-6 = Mental Health), extended
#    consistently to the remaining modules. Two modules are tagged with the two special
#    Section 29 %-indicators instead of a pillar, so those indicators compute directly.
# --------------------------------------------------------------------------------------
PHASE1_EMPLOYEE_MODULES = [
    (1, "Understanding POCSO & Child Safeguarding", "POCSO & Child Safeguarding"),
    (2, "Identifying, Responding & Reporting", "POCSO & Child Safeguarding"),
    (3, "Safe Adult-Child Boundaries", "POCSO & Child Safeguarding"),
    (4, "POSH & Safe Workplace Practices", "POSH & Safe Workplace Practices"),
    (5, "Mental Health & Emotional Wellbeing", "Mental Health & Emotional Wellbeing"),
    (6, "Recognise -> Respond -> Refer", "Mental Health & Emotional Wellbeing"),
    (7, "Grievance & Escalation Mechanisms", "Reporting Mechanism Awareness"),
    (8, "Creating a Safe Residential Environment", "POCSO & Child Safeguarding"),
]
PHASE2_STUDENT_MODULES = [
    (1, "My Safety, My Rights", "POCSO & Child Safeguarding"),
    (2, "Safe and Unsafe Behaviour", "POCSO & Child Safeguarding"),
    (3, "Personal Boundaries", "POCSO & Child Safeguarding"),
    (4, "Understanding Abuse & Harassment", "POCSO & Child Safeguarding"),
    (5, "Speaking Up & Seeking Help", "Trusted Help Channels Awareness"),
    (6, "POCSO Awareness", "POCSO & Child Safeguarding"),
    (7, "Understanding My Emotions", "Mental Health & Emotional Wellbeing"),
    (8, "Managing Stress & Difficult Emotions", "Mental Health & Emotional Wellbeing"),
    (9, "Peer Relationships & Bullying", "Mental Health & Emotional Wellbeing"),
    (10, "Resilience", "Mental Health & Emotional Wellbeing"),
    (11, "Trusted Adults & Support Systems", "Trusted Help Channels Awareness"),
    (12, "My Safety & Wellbeing Plan", "Mental Health & Emotional Wellbeing"),
]

EMPLOYEE_ROLES = ["Warden", "Assistant Warden", "Cook", "Helper",
                  "Security Guard", "ANM / Health Worker", "Accountant / Clerk", "Peon"]

ISSUE_POOL = [
    "Escalation flowchart not yet displayed in hostel common area",
    "Personnel training not yet started for this cycle",
    "Post-assessment pending for Batch 2 students",
    "Facilitator adherence flagged as needs improvement during QA visit",
    "Grievance box not installed in hostel premises",
    "Refresher session required for newly joined warden",
    "IEC posters not yet displayed in student common areas",
    "Digital reference material access pending at institution",
]

# --------------------------------------------------------------------------------------
# Sample-scale sizing (bump these up, and extend DISTRICTS to all 55, for SCALE="full")
# --------------------------------------------------------------------------------------
INSTITUTES_PER_DISTRICT_RANGE = (5, 8)      # ~50 institutes across 8 districts
STUDENTS_PER_INSTITUTE_RANGE = (25, 45)
EMPLOYEES_PER_INSTITUTE = len(EMPLOYEE_ROLES)   # 1 of each role per institute = 8
QUESTIONS_PER_MODULE_STAGE = 5              # 4 MCQ + 1 self-rating confidence item

FY_START = date(2026, 4, 1)
FY_END = date(2027, 3, 31)


# ========================================================================================
# DIM_DATE
# ========================================================================================
def build_dim_date():
    days = pd.date_range(FY_START, FY_END, freq="D")
    df = pd.DataFrame({"Date": days})
    df["Date_Key"] = df["Date"].dt.strftime("%Y%m%d").astype(int)
    df["Day"] = df["Date"].dt.day
    df["Day_Name"] = df["Date"].dt.day_name()
    df["Day_Number"] = df["Date"].dt.dayofweek + 1
    df["Month"] = df["Date"].dt.month
    df["Month_Name"] = df["Date"].dt.month_name()
    # Indian FY quarter: Q1=Apr-Jun ... Q4=Jan-Mar
    df["Quarter_Number"] = ((df["Date"].dt.month - 4) % 12) // 3 + 1
    df["Quarter"] = "Q" + df["Quarter_Number"].astype(str)
    df["Year"] = df["Date"].dt.year
    df["Year_Month"] = df["Date"].dt.strftime("%Y-%m")
    df["Week_Number"] = df["Date"].dt.isocalendar().week.astype(int)
    return df[["Date_Key", "Date", "Day", "Day_Name", "Day_Number", "Month", "Month_Name",
               "Quarter", "Quarter_Number", "Year", "Year_Month", "Week_Number"]]


def date_key(d):
    return int(d.strftime("%Y%m%d"))


# ========================================================================================
# DIM_DISTRICT
# ========================================================================================
def build_dim_district():
    rows = []
    for i, (code, name) in enumerate(DISTRICTS, start=1):
        rows.append({"District_Key": i, "District_ID": f"DIST-{code}", "District_Code": code, "District_Name": name})
    return pd.DataFrame(rows)


# ========================================================================================
# DIM_INSTITUTE
# ========================================================================================
def build_dim_institute(dim_district):
    rows = []
    key = 1
    for _, drow in dim_district.iterrows():
        n_inst = RNG.integers(INSTITUTES_PER_DISTRICT_RANGE[0], INSTITUTES_PER_DISTRICT_RANGE[1] + 1)
        n_kgbv = int(round(n_inst * 0.52))
        n_nscbav = n_inst - n_kgbv
        seq = 1
        for _ in range(n_kgbv):
            rows.append({
                "Institute_Key": key, "Inst_ID": f"INST-{drow.District_Code}-K{seq:02d}",
                "Inst_Name": f"KGBV {drow.District_Name} {seq}", "Inst_Type": "KGBV",
                "District_ID": drow.District_ID,
            })
            key += 1; seq += 1
        seq = 1
        for _ in range(n_nscbav):
            rows.append({
                "Institute_Key": key, "Inst_ID": f"INST-{drow.District_Code}-N{seq:02d}",
                "Inst_Name": f"NSCBAV {drow.District_Name} Hostel {chr(64+seq)}", "Inst_Type": "NSCBAV",
                "District_ID": drow.District_ID,
            })
            key += 1; seq += 1
    return pd.DataFrame(rows)


# ========================================================================================
# DIM_MODULE  (extends the diagram's 3 columns with Phase / Audience / Pillar — see README)
# ========================================================================================
def build_dim_module():
    rows = []
    key = 1
    for mid, name, pillar in PHASE1_EMPLOYEE_MODULES:
        rows.append({"Module_Key": key, "Module_ID": f"P1-M{mid:02d}", "Module_Name": name,
                      "Phase": "Phase I", "Audience": "Employee", "Pillar": pillar})
        key += 1
    for mid, name, pillar in PHASE2_STUDENT_MODULES:
        rows.append({"Module_Key": key, "Module_ID": f"P2-M{mid:02d}", "Module_Name": name,
                      "Phase": "Phase II", "Audience": "Student", "Pillar": pillar})
        key += 1
    return pd.DataFrame(rows)


# ========================================================================================
# DIM_QUESTION
# ========================================================================================
def build_dim_question(dim_module):
    rows = []
    key = 1
    for _, m in dim_module.iterrows():
        for stage in ["Pre", "Post"]:
            for qn in range(1, QUESTIONS_PER_MODULE_STAGE + 1):
                is_rating = (qn == QUESTIONS_PER_MODULE_STAGE)  # last item per module/stage = self-rating
                qtype = "Rating" if is_rating else "MCQ"
                correct = "" if is_rating else RNG.choice(["Option A", "Option B", "Option C", "Option D"])
                max_score = 5 if is_rating else 1
                prefix = "P_Q" if stage == "Post" else "Q"
                rows.append({
                    "Question_Key": key,
                    "Question_ID": f"{prefix}{qn}_{m.Module_ID}",
                    "Module_ID": m.Module_ID,
                    "Competency": m.Pillar,
                    "Question_Text_EN": (f"Self-rated confidence check — {m.Module_Name} ({stage}-training)"
                                          if is_rating else
                                          f"{stage}-training knowledge check {qn} — {m.Module_Name}"),
                    "Question_Type": qtype,
                    "Correct_Answer": correct,
                    "Max_Score": max_score,
                    "Stage": stage,
                })
                key += 1
    return pd.DataFrame(rows)


# ========================================================================================
# DIM_STUDENT / DIM_EMPLOYEE
# ========================================================================================
def build_dim_student(dim_institute):
    rows = []
    key = 1
    for _, inst in dim_institute.iterrows():
        n = RNG.integers(STUDENTS_PER_INSTITUTE_RANGE[0], STUDENTS_PER_INSTITUTE_RANGE[1] + 1)
        hostel_gender = "Girls" if inst.Inst_Type == "KGBV" else RNG.choice(["Girls", "Boys"])
        for s in range(1, n + 1):
            grade = int(RNG.choice([6, 7, 8, 9, 10]))
            age = {6: "11-12", 7: "12-13", 8: "13-14", 9: "14-15", 10: "15-16"}[grade]
            rows.append({
                "Student_Key": key, "Student_ID": f"STU-{inst.Inst_ID}-{s:03d}",
                "Age_Group": age, "Class": f"Class {grade}", "Hostel_Type": hostel_gender + " Hostel",
                "School_Code": inst.Inst_ID, "Gender": "Female" if hostel_gender == "Girls" else "Male",
                "Other_Attributes": "",
            })
            key += 1
    return pd.DataFrame(rows)


def build_dim_employee(dim_institute):
    rows = []
    key = 1
    for _, inst in dim_institute.iterrows():
        for role in EMPLOYEE_ROLES:
            rows.append({
                "Employee_Key": key, "Employee_ID": f"EMP-{inst.Inst_ID}-{role[:3].upper()}",
                "Department": role, "Class": "", "Hostel_Type": "Staff Quarters",
                "School_Code": inst.Inst_ID, "Gender": RNG.choice(["Female", "Male"]),
                "Other_Attributes": "",
            })
            key += 1
    return pd.DataFrame(rows)


# ========================================================================================
# SCORING MODEL — shared by both fact builders
# ========================================================================================
PILLAR_BASE_PRE = {
    "POCSO & Child Safeguarding": 0.55,
    "POSH & Safe Workplace Practices": 0.50,
    "Mental Health & Emotional Wellbeing": 0.52,
    "Reporting Mechanism Awareness": 0.45,
    "Trusted Help Channels Awareness": 0.48,
}
PILLAR_GAIN = {
    "POCSO & Child Safeguarding": 0.25,
    "POSH & Safe Workplace Practices": 0.22,
    "Mental Health & Emotional Wellbeing": 0.20,
    "Reporting Mechanism Awareness": 0.30,
    "Trusted Help Channels Awareness": 0.28,
}


def institute_factors(dim_institute):
    fac = RNG.normal(1.0, 0.08, size=len(dim_institute)).clip(0.85, 1.15)
    return dict(zip(dim_institute["Inst_ID"], fac))


def district_factors(dim_district):
    fac = RNG.normal(1.0, 0.05, size=len(dim_district)).clip(0.90, 1.10)
    return dict(zip(dim_district["District_ID"], fac))


def gen_score(pillar, stage, inst_factor, dist_factor, is_rating):
    base = PILLAR_BASE_PRE[pillar]
    gain = PILLAR_GAIN[pillar]
    p = base if stage == "Pre" else base + gain
    p = float(np.clip(p * inst_factor * dist_factor, 0.15, 0.97))
    if is_rating:
        centre = 2.6 + 2.2 * p          # maps prob-ish score to a 1-5 confidence rating
        val = int(np.clip(round(RNG.normal(centre, 0.6)), 1, 5))
        return val, str(val)
    else:
        correct = RNG.random() < p
        return (1, "Correct") if correct else (0, "Incorrect")


# ========================================================================================
# FACT_RESPONSE_STUDENT / FACT_RESPONSE_EMPLOYEE
# ========================================================================================
def assessment_window(rng_offset_days=(0, 20)):
    pre = FY_START + timedelta(days=30 + int(RNG.integers(*rng_offset_days)))     # ~May 2026
    post = pre + timedelta(days=110 + int(RNG.integers(0, 20)))                    # ~3.5-4 months later
    return pre, post


def build_fact_response(dim_institute, dim_module, dim_question, dim_person, person_key_col,
                         id_col, audience, inst_fac, dist_fac):
    q_by_module = {mid: g for mid, g in dim_question.groupby("Module_ID")}
    modules = dim_module[dim_module.Audience == audience]
    inst_lookup = dim_institute.set_index("Inst_ID")
    windows = {inst_id: assessment_window() for inst_id in dim_institute["Inst_ID"]}

    rows = []
    resp_id = 1
    persons_by_inst = dim_person.groupby("School_Code")
    for inst_id, ppl in persons_by_inst:
        inst_row = inst_lookup.loc[inst_id]
        district_id = inst_row.District_ID
        pre_date, post_date = windows[inst_id]
        for _, person in ppl.iterrows():
            for _, m in modules.iterrows():
                for stage, adate in (("Pre", pre_date), ("Post", post_date)):
                    qs = q_by_module[m.Module_ID]
                    qs = qs[qs.Stage == stage]
                    load_ts = pd.Timestamp(adate) + pd.Timedelta(days=int(RNG.integers(2, 6)),
                                                                   hours=int(RNG.integers(8, 18)))
                    for _, q in qs.iterrows():
                        is_rating = q.Question_Type == "Rating"
                        score, resp_text = gen_score(q.Competency, stage, inst_fac[inst_id],
                                                      dist_fac[district_id], is_rating)
                        rows.append({
                            "Response_ID": resp_id,
                            "Date_Key": date_key(adate),
                            person_key_col: person[person_key_col],
                            "District_Key": district_id,          # resolved to surrogate key later
                            "Institute_Key": inst_id,               # resolved to surrogate key later
                            "Module_Key": m.Module_ID,              # resolved to surrogate key later
                            "Question_Key": q.Question_Key,
                            "Response": resp_text if not is_rating else resp_text,
                            "Score": score,
                            "Stage": stage,
                            "Assessment_ID": f"{inst_id}-{m.Module_ID}-{stage}",
                            "Load_Timestamp": load_ts,
                        })
                        resp_id += 1
    return pd.DataFrame(rows)


def resolve_surrogate_keys(fact_df, dim_district, dim_institute, dim_module):
    dmap = dim_district.set_index("District_ID")["District_Key"].to_dict()
    imap = dim_institute.set_index("Inst_ID")["Institute_Key"].to_dict()
    mmap = dim_module.set_index("Module_ID")["Module_Key"].to_dict()
    fact_df["District_Key"] = fact_df["District_Key"].map(dmap)
    fact_df["Institute_Key"] = fact_df["Institute_Key"].map(imap)
    fact_df["Module_Key"] = fact_df["Module_Key"].map(mmap)
    return fact_df


# ========================================================================================
# BONUS TABLES (flagged as additions beyond the original diagram)
# ========================================================================================
def build_ref_coverage_targets(dim_institute, dim_district):
    """Eligible-population denominators needed to turn 'assessed so far' into true
    coverage % against target — the diagram's fact tables alone have no denominator."""
    rows = []
    for _, d in dim_district.iterrows():
        for itype in ["KGBV", "NSCBAV"]:
            assessed = dim_institute[(dim_institute.District_ID == d.District_ID) &
                                      (dim_institute.Inst_Type == itype)]
            n_assessed = len(assessed)
            if n_assessed == 0:
                continue
            rollout_ratio = float(RNG.uniform(0.55, 0.85))   # assessed institutes are a partial rollout
            eligible_inst = max(n_assessed, int(round(n_assessed / rollout_ratio)))
            rows.append({
                "District_Name": d.District_Name, "Inst_Type": itype,
                "Eligible_Institutions": eligible_inst,
                "Eligible_Students": eligible_inst * 35,
                "Eligible_Personnel": eligible_inst * len(EMPLOYEE_ROLES),
            })
    return pd.DataFrame(rows)


def build_fact_action_points(dim_institute, dim_district):
    dmap = dim_district.set_index("District_ID")["District_Name"].to_dict()
    rows = []
    ap_id = 1
    today_ref = FY_START + timedelta(days=200)
    for _, inst in dim_institute.iterrows():
        n_issues = RNG.integers(0, 3)
        for _ in range(n_issues):
            raised = FY_START + timedelta(days=int(RNG.integers(40, 220)))
            status = RNG.choice(["Open", "In Progress", "Closed"], p=[0.30, 0.30, 0.40])
            days_open = (today_ref - raised).days if status != "Closed" else int(RNG.integers(3, 25))
            rows.append({
                "Action_Point_ID": f"AP-{ap_id:04d}",
                "Inst_ID": inst.Inst_ID,
                "District_Name": dmap[inst.District_ID],
                "Description": RNG.choice(ISSUE_POOL),
                "Raised_On": raised,
                "Status": status,
                "Days_Open": max(days_open, 0),
            })
            ap_id += 1
    return pd.DataFrame(rows)


# ========================================================================================
# MAIN
# ========================================================================================
def main():
    dim_date = build_dim_date()
    dim_district = build_dim_district()
    dim_institute = build_dim_institute(dim_district)
    dim_module = build_dim_module()
    dim_question = build_dim_question(dim_module)
    dim_student = build_dim_student(dim_institute)
    dim_employee = build_dim_employee(dim_institute)

    inst_fac = institute_factors(dim_institute)
    dist_fac = district_factors(dim_district)

    fact_student = build_fact_response(dim_institute, dim_module, dim_question, dim_student,
                                        "Student_Key", "Student_ID", "Student", inst_fac, dist_fac)
    fact_student = resolve_surrogate_keys(fact_student, dim_district, dim_institute, dim_module)
    fact_student = fact_student[["Response_ID", "Date_Key", "Student_Key", "District_Key",
                                  "Institute_Key", "Module_Key", "Question_Key", "Response",
                                  "Score", "Stage", "Assessment_ID", "Load_Timestamp"]]

    fact_employee = build_fact_response(dim_institute, dim_module, dim_question, dim_employee,
                                         "Employee_Key", "Employee_ID", "Employee", inst_fac, dist_fac)
    fact_employee = resolve_surrogate_keys(fact_employee, dim_district, dim_institute, dim_module)
    fact_employee = fact_employee[["Response_ID", "Date_Key", "Employee_Key", "District_Key",
                                    "Institute_Key", "Module_Key", "Question_Key", "Response",
                                    "Score", "Stage", "Assessment_ID", "Load_Timestamp"]]

    ref_targets = build_ref_coverage_targets(dim_institute, dim_district)
    fact_action_points = build_fact_action_points(dim_institute, dim_district)

    # Institute/Student/Employee dims: drop the helper School_Code->District linkage duplication? keep as-is, matches diagram.
    dim_institute_out = dim_institute.drop(columns=[])  # District_ID kept per diagram

    readme_rows = [
        ["Scope", "SAMPLE / PROTOTYPING dataset — not the real programme's data. All names, IDs and scores are synthetic."],
        ["Scale generated", f"{len(dim_district)} districts, {len(dim_institute)} institutes, "
                             f"{len(dim_student)} students, {len(dim_employee)} employees, "
                             f"{len(fact_student) + len(fact_employee):,} total response rows."],
        ["To go statewide", "Edit generate_rsk_sample_data.py: extend DISTRICTS to all 55 MP districts, "
                             "raise INSTITUTES_PER_DISTRICT_RANGE so totals reach 798 (408 KGBV + 390 NSCBAV), "
                             "and re-run. The script is fully parameterised — no other change needed."],
        ["Core tables (from your diagram)", "Dim_Date, Dim_District, Dim_Institute, Dim_Student, Dim_Employee, "
                                             "Dim_Module, Dim_Question, Fact_Response_Student, Fact_Response_Employee."],
        ["Bonus tables (NOT in your original diagram)", "Ref_Coverage_Targets and Fact_Action_Points. Added because "
                                                          "the coverage %/institutional-action-point tiles already in "
                                                          "your Main/District/State wireframes cannot be computed from "
                                                          "assessment-response data alone — see the DAX Measures Library doc."],
        ["Dim_Module extension", "Phase / Audience / Pillar columns added beyond the diagram's 3 columns — matches "
                                  "the 'Dim_Competency' idea already in your own 'Optional Additions' box, folded into "
                                  "Dim_Module instead of a separate table to keep the model at 9+2 tables, not 10+2."],
        ["Assumptions to sanity-check with the real data", "Hostel_Type/Gender inferred (KGBV = girls; NSCBAV = mixed); "
                                                             "5 questions per module per stage (4 MCQ + 1 self-rating); "
                                                             "all students take all 12 Phase II modules in one cycle; "
                                                             "one assessment window (Pre + Post) per institute per FY."],
    ]
    df_readme = pd.DataFrame(readme_rows, columns=["Item", "Notes"])

    out_path = "RSK_Sample_Synthetic_Dataset.xlsx"
    with pd.ExcelWriter(out_path, engine="openpyxl") as xw:
        df_readme.to_excel(xw, sheet_name="README", index=False)
        dim_date.to_excel(xw, sheet_name="Dim_Date", index=False)
        dim_district.to_excel(xw, sheet_name="Dim_District", index=False)
        dim_institute_out.to_excel(xw, sheet_name="Dim_Institute", index=False)
        dim_student.to_excel(xw, sheet_name="Dim_Student", index=False)
        dim_employee.to_excel(xw, sheet_name="Dim_Employee", index=False)
        dim_module.to_excel(xw, sheet_name="Dim_Module", index=False)
        dim_question.to_excel(xw, sheet_name="Dim_Question", index=False)
        fact_student.to_excel(xw, sheet_name="Fact_Response_Student", index=False)
        fact_employee.to_excel(xw, sheet_name="Fact_Response_Employee", index=False)
        ref_targets.to_excel(xw, sheet_name="Ref_Coverage_Targets", index=False)
        fact_action_points.to_excel(xw, sheet_name="Fact_Action_Points", index=False)

        # widen README columns a touch
        ws = xw.sheets["README"]
        ws.column_dimensions["A"].width = 34
        ws.column_dimensions["B"].width = 110

    print(f"Written {out_path}")
    print(f"Districts: {len(dim_district)}  Institutes: {len(dim_institute)}  "
          f"Students: {len(dim_student)}  Employees: {len(dim_employee)}")
    print(f"Fact_Response_Student rows: {len(fact_student):,}")
    print(f"Fact_Response_Employee rows: {len(fact_employee):,}")
    print(f"Fact_Action_Points rows: {len(fact_action_points):,}")


if __name__ == "__main__":
    main()
